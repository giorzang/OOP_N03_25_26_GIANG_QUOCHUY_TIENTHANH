package nhom3.rausachonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RausachonlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(RausachonlineApplication.class, args);
	}

}
